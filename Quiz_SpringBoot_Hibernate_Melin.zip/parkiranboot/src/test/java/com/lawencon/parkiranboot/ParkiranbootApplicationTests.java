package com.lawencon.parkiranboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParkiranbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
