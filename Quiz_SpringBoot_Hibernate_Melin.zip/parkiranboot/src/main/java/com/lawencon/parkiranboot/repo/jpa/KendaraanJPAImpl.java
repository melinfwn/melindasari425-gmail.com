package com.lawencon.parkiranboot.repo.jpa;

import java.time.LocalDate;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.lawencon.parkiranboot.model.Kendaraan;

@Repository("kendaraan_repo_jpa")
public class KendaraanJPAImpl implements KendaraanJPA {

	@Autowired
	KendaraanRepo kdRepo;

	@Override
	public Kendaraan checkIn(Kendaraan kendaraan) throws Exception {
		kendaraan.setStatus("Check In");
		kendaraan.setTglIn(LocalDate.now());
		kdRepo.save(kendaraan);
		return kendaraan;
	}

	@Override
	public List<Kendaraan> showCheckIn() throws Exception {
		return kdRepo.findByStatus("Check In");
	}

	@Override
	public List<Kendaraan> showCheckOut() throws Exception {
		return kdRepo.findByStatus("Check Out");
	}

	@Override
	public List<Kendaraan> showByJenis(String jenis) throws Exception {
		return kdRepo.findByJenisKendaraan(jenis);
	}

	@Override
	public Kendaraan findById(Long id) throws Exception {
		return kdRepo.findById(id).orElse(null);
	}

	@Override
	public void delete(Long id) throws Exception {
		kdRepo.deleteById(id);
		
	}

}
