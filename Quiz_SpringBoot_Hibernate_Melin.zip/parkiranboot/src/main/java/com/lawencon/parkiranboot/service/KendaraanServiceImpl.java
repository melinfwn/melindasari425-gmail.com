package com.lawencon.parkiranboot.service;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import com.lawencon.parkiranboot.model.Kendaraan;
import com.lawencon.parkiranboot.repo.hibernate.BaseHibernate;
import com.lawencon.parkiranboot.repo.hibernate.KendaraanHibernateImpl;

@Service
@Transactional
public class KendaraanServiceImpl extends BaseHibernate implements KendaraanService {
	
	@Autowired
	@Qualifier("kendaraan_repo_hibernate")
	private KendaraanHibernateImpl kendaraanService;

	@Override
	public Kendaraan checkIn(Kendaraan kendaraan) throws Exception {
		return kendaraanService.checkIn(kendaraan);
	}

	@Override
	public Boolean validNomor(Kendaraan kendaraan) {
		return kendaraanService.validNomor(kendaraan);
	}

	@Override
	public Kendaraan checkOut(Long id) throws Exception {
		return kendaraanService.checkOut(id);
	}

	
	@Override
	public List<Kendaraan> showCheckIn() throws Exception {
		return kendaraanService.showCheckIn();
	}

	@Override
	public List<Kendaraan> showCheckOut() throws Exception {
		return kendaraanService.showCheckOut();
	}

	@Override
	public List<Kendaraan> showByJenis(String jenis) throws Exception {
		return kendaraanService.showByJenis(jenis);
	}

	@Override
	public List<Kendaraan> findById(Long id) throws Exception {
		return kendaraanService.findById(id);
	}

	@Override
	public void delete(Long id) throws Exception {
		kendaraanService.delete(id);

	}

}
