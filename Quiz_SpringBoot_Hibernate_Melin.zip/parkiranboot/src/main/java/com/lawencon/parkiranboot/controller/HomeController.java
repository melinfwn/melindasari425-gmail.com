package com.lawencon.parkiranboot.controller;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lawencon.parkiranboot.model.Kendaraan;
import com.lawencon.parkiranboot.model.UserLogin;
import com.lawencon.parkiranboot.service.KendaraanService;
import com.lawencon.parkiranboot.service.UserService;

@RestController
public class HomeController {

	@Autowired
	private KendaraanService kendaraanService;

	@Autowired
	private UserService userService;

	@PostMapping("/home/checkin")
	public ResponseEntity<Kendaraan> CheckIn(@RequestBody String content, @RequestHeader("username") String username,
			@RequestHeader("password") String password) {
		Kendaraan k = new Kendaraan();
		List<UserLogin> user = new ArrayList<UserLogin>();
		try {
			user = userService.findByUsernamePassword(username, password);
			if (user.isEmpty()) {
				System.out.println("User tidak valid!");
			} else {
				k = new ObjectMapper().readValue(content, Kendaraan.class);
//				Boolean check = kendaraanService.validNomor(k);
//				if (check == true) {
					kendaraanService.checkIn(k);
					return new ResponseEntity<>(k, HttpStatus.UNAUTHORIZED);
//				} else
//					return new ResponseEntity<>(k, HttpStatus.BAD_REQUEST);
			}
			return new ResponseEntity<>(k, HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(k, HttpStatus.BAD_REQUEST);
		}
	}

	@PostMapping("/home/checkout")
	public ResponseEntity<String> checkOut(@RequestParam("id") Long id, @RequestHeader("username") String username,
			@RequestHeader("password") String password) {
		List<UserLogin> user = new ArrayList<UserLogin>();
		try {
			user = userService.findByUsernamePassword(username, password);
			if (user.isEmpty()) {
				System.out.println("User tidak valid!");
			} else {
				kendaraanService.checkOut(id);
				return new ResponseEntity<>("Berhasil", HttpStatus.UNAUTHORIZED);
			}
			return new ResponseEntity<>("Gagal.", HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>("Gagal.", HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping("/home/getjenis")
	public ResponseEntity<List<Kendaraan>> getJenis(@RequestParam("jenisKendaraan") String jenisKendaraan,
			@RequestHeader("username") String username, @RequestHeader("password") String password) {
		List<Kendaraan> list = new ArrayList<Kendaraan>();
		List<UserLogin> user = new ArrayList<UserLogin>();
		try {
			user = userService.findByUsernamePassword(username, password);
			if (user.isEmpty()) {
				System.out.println("User tidak valid!");
			} else {
				list = kendaraanService.showByJenis(jenisKendaraan);
				return new ResponseEntity<>(list, HttpStatus.UNAUTHORIZED);
			}
			return new ResponseEntity<>(list, HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(list, HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping("/home/getid")
	public ResponseEntity<List<Kendaraan>> getById(@RequestParam("id") Long id,
			@RequestHeader("username") String username, @RequestHeader("password") String password) {
		List<UserLogin> user = new ArrayList<UserLogin>();
		List<Kendaraan> list = new ArrayList<Kendaraan>();
		try {
			user = userService.findByUsernamePassword(username, password);
			if (user.isEmpty()) {
				System.out.println("User tidak valid!");
			} else {
				list = kendaraanService.findById(id);
				return new ResponseEntity<>(list, HttpStatus.UNAUTHORIZED);
			}
			return new ResponseEntity<>(list, HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(list, HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping("/home/listin")
	public ResponseEntity<List<Kendaraan>> showCheckIn(@RequestHeader("username") String username,
			@RequestHeader("password") String password) {
		List<Kendaraan> listCheckIn = new ArrayList<Kendaraan>();
		List<UserLogin> user = new ArrayList<UserLogin>();
		try {
			user = userService.findByUsernamePassword(username, password);
			if (user.isEmpty()) {
				System.out.println("User tidak valid!");
			} else {
				listCheckIn = kendaraanService.showCheckIn();
				return new ResponseEntity<>(listCheckIn, HttpStatus.UNAUTHORIZED);
			}
			return new ResponseEntity<>(listCheckIn, HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(listCheckIn, HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping("/home/listout")
	public ResponseEntity<List<Kendaraan>> showCheckOut(@RequestHeader("username") String username,
			@RequestHeader("password") String password) {
		List<Kendaraan> listCheckOut = new ArrayList<Kendaraan>();
		List<UserLogin> user = new ArrayList<UserLogin>();
		try {
			user = userService.findByUsernamePassword(username, password);
			if (user.isEmpty()) {
				System.out.println("User tidak valid!");
			} else {
				listCheckOut = kendaraanService.showCheckOut();
				return new ResponseEntity<>(listCheckOut, HttpStatus.UNAUTHORIZED);
			}
			return new ResponseEntity<>(listCheckOut, HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(listCheckOut, HttpStatus.BAD_REQUEST);
		}
	}

	@PostMapping("/home/delete")
	public ResponseEntity<String> delete(@RequestParam("id") Long id, @RequestHeader("username") String username,
			@RequestHeader("password") String password) {
		List<UserLogin> user = new ArrayList<UserLogin>();
		try {
			user = userService.findByUsernamePassword(username, password);
			if (user.isEmpty()) {
				System.out.println("User tidak valid!");
			} else {
				kendaraanService.delete(id);
				return new ResponseEntity<>("Berhasil", HttpStatus.UNAUTHORIZED);
			}
			return new ResponseEntity<>("Gagal.", HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>("Gagal.", HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping("/home/user")
	public ResponseEntity<List<UserLogin>> showUser(@RequestParam("username") String username,
			@RequestParam("password") String password) {
		try {
			userService.findByUsernamePassword(username, password);
			return new ResponseEntity<>(userService.findByUsernamePassword(username, password),
					HttpStatus.UNAUTHORIZED);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(userService.findByUsernamePassword(username, password), HttpStatus.BAD_REQUEST);
		}
	}

}
