package com.lawencon.parkiranboot.repo;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.lawencon.parkiranboot.model.Kendaraan;

@Repository
public interface KendaraanRepo extends JpaRepository<Kendaraan, Long> {
	List<Kendaraan> findByStatus(String status);
}
